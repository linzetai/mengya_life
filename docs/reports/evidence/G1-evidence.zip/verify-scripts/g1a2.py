import sys, time
sys.path.insert(0, "/tmp")
from g1lib import *

# 归位：若停在设置页，先返回
close_keyboard()
if any(n["rid"] == "settings_back" for n in nodes(dump())):
    adb("shell input keyevent KEYCODE_BACK"); time.sleep(1.2)

TABS = [("tab_overview", "03-overview", "你正在走的方向"),
        ("tab_goals",    "04-goals",    "把方向拆成能推进的层级"),
        ("tab_trends",   "05-trends",   "看见变化，而不是凭感觉"),
        ("tab_diary",    "06-diary",    "把今天留下来"),
        ("tab_advisor",  "07-advisor",  None)]

for tag, name, headline in TABS:
    ok = tap_tag(tag)
    check(f"切换到 {tag}", ok)
    xml = dump()
    ts = texts(xml)
    if headline:
        check(f"{tag} 页面标题正确", headline in ts, headline)
    if tag == "tab_advisor":
        ns = nodes(xml)
        check("顾问页有输入框", any(n["rid"] == "advisor_input" for n in ns))
        check("顾问页有发送按钮", any(n["rid"] == "advisor_send" for n in ns))
    shot(name)

for tag, _, headline in TABS[:-1]:
    tap_tag(tag)
    check(f"{tag} 打开设置", tap_tag("btn_settings"))
    sn = nodes(dump())
    check("设置页可见", any(n["text"] == "设置" for n in sn))
    check("设置页隐藏底部导航", not any(n["rid"].startswith("tab_") for n in sn))
    check("设置页有返回按钮", any(n["rid"] == "settings_back" for n in sn))
    adb("shell input keyevent KEYCODE_BACK")
    time.sleep(1.4)
    bx = dump()
    check(f"{tag} 系统返回键回到原页面", headline in texts(bx), headline)
    check(f"{tag} 返回后底部导航恢复", any(n["rid"].startswith("tab_") for n in nodes(bx)))

tap_tag("tab_overview")
tap_tag("btn_settings")
time.sleep(1.0)
shot("08-settings-light")
check("设置页浅色截图", True)

sys.exit(0 if summary() else 1)
