import re, subprocess, time, os, struct, zlib

DEV = os.environ.get("DEV", "192.168.96.181:34157")
OUT = "docs/reports/logs/g1-shots"
os.makedirs(OUT, exist_ok=True)

def adb(cmd, t=120, binary=False):
    r = subprocess.run(f"adb -s {DEV} {cmd}", shell=True, capture_output=True, timeout=t)
    return r.stdout if binary else r.stdout.decode("utf-8", "replace")

def dump(retries=4):
    xml = ""
    for _ in range(retries):
        adb("shell uiautomator dump /sdcard/u.xml >/dev/null 2>&1")
        xml = adb("shell cat /sdcard/u.xml")
        if xml.strip().startswith("<?xml"):
            return xml
        time.sleep(1.0)
    return xml

def nodes(xml):
    out = []
    for m in re.finditer(r"<node[^>]*?/?>", xml):
        t = m.group(0)
        def g(k):
            mm = re.search(k + r'="([^"]*)"', t)
            return mm.group(1) if mm else ""
        mb = re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', t)
        x1 = y1 = x2 = y2 = 0
        if mb:
            x1, y1, x2, y2 = map(int, mb.groups())
        out.append(dict(text=g("text"), rid=g("resource-id"), desc=g("content-desc"),
                        checked=g("checked"), center=((x1 + x2) // 2, (y1 + y2) // 2)))
    return out

def texts(xml):
    return [n["text"] for n in nodes(xml) if n["text"].strip()]

def close_keyboard():
    for _ in range(2):
        if "mInputShown=true" not in adb("shell dumpsys input_method"):
            return True
        adb("shell input keyevent KEYCODE_BACK")
        time.sleep(1.0)
    return "mInputShown=true" not in adb("shell dumpsys input_method")

def tap_xy(x, y, wait=1.4):
    adb(f"shell input tap {x} {y}")
    time.sleep(wait)

def tap_tag(tag, wait=1.4, scroll=False, max_swipes=8):
    if scroll:
        scroll_to_tag(tag, max_swipes)
    for _ in range(3):
        for n in nodes(dump()):
            if n["rid"] == tag:
                tap_xy(*n["center"], wait=wait)
                return True
        time.sleep(0.8)
    return False

def scroll_to_tag(tag, max_swipes=8):
    for _ in range(max_swipes):
        if any(n["rid"] == tag for n in nodes(dump())):
            return True
        adb("shell input swipe 600 1900 600 800 260")
        time.sleep(1.0)
    return False

def shot(name):
    d = adb("exec-out screencap -p", binary=True)
    i = d.find(b"\x89PNG")
    path = f"{OUT}/{name}.png"
    open(path, "wb").write(d[i:])
    return path

def png_luminance(path):
    d = open(path, "rb").read()
    if d[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    pos, idat, w, h, ct = 8, b"", 0, 0, 6
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos+4])[0]
        typ = d[pos+4:pos+8]
        data = d[pos+8:pos+8+ln]
        if typ == b"IHDR":
            w, h, bd, ct = struct.unpack(">IIBB", data[:10])
        elif typ == b"IDAT":
            idat += data
        elif typ == b"IEND":
            break
        pos += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0:1, 2:3, 3:1, 4:2, 6:4}[ct]
    stride = w * ch
    prev = bytearray(stride)
    p = 0
    total, n = 0.0, 0
    for y in range(h):
        f = raw[p]; p += 1
        line = bytearray(raw[p:p+stride]); p += stride
        if f == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i-ch]) & 0xFF
        elif f == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif f == 3:
            for i in range(stride):
                a = line[i-ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif f == 4:
            for i in range(stride):
                a = line[i-ch] if i >= ch else 0
                b = prev[i]
                c = prev[i-ch] if i >= ch else 0
                pp = a + b - c
                pa, pb, pc = abs(pp-a), abs(pp-b), abs(pp-c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        prev = line
        if y % 10 == 0:
            for x in range(0, w, 19):
                o = x * ch
                if ch >= 3:
                    r, g, b = line[o], line[o+1], line[o+2]
                else:
                    r = g = b = line[o]
                total += 0.2126*r + 0.7152*g + 0.0722*b
                n += 1
    return total / n if n else None

RESULTS = []
def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(("PASS  " if cond else "FAIL  ") + name + (("  " + detail) if detail else ""))

def summary():
    p = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"\n==== SUMMARY: {p}/{len(RESULTS)} passed ====")
    for n, ok, d in RESULTS:
        if not ok:
            print("FAILED:", n, d)
    return p == len(RESULTS)
