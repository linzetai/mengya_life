import sys, time
sys.path.insert(0, "/tmp")
from g1lib import *

close_keyboard()
# 确保在设置页
if not any(n["rid"] == "settings_back" for n in nodes(dump())):
    tap_tag("tab_overview"); tap_tag("btn_settings")
time.sleep(0.8)

# ---------- 主题：浅色 / 深色 / 跟随系统 ----------
check("滚动到外观分组", scroll_to_tag("theme_dark"))
time.sleep(0.6)
light_path = shot("09-settings-light-theme")
L_light = png_luminance(light_path)

check("点击深色模式", tap_tag("theme_dark"))
time.sleep(1.6)
dn = nodes(dump())
check("深色被选中（checked=true）",
      any(n["rid"] == "theme_dark" and n["checked"] == "true" for n in dn),
      str([(n["rid"], n["checked"]) for n in dn if n["rid"].startswith("theme_")]))
dark_path = shot("10-settings-dark")
L_dark = png_luminance(dark_path)
check("深色模式整体变暗（程序化断言）",
      L_dark is not None and L_light is not None and L_dark < L_light - 60,
      f"light_L={L_light:.1f} dark_L={L_dark:.1f}")

check("切回浅色", tap_tag("theme_light"))
time.sleep(1.6)
ln = nodes(dump())
check("浅色被选中", any(n["rid"] == "theme_light" and n["checked"] == "true" for n in ln))
L_back = png_luminance(shot("11-settings-light-again"))
check("浅色恢复变亮", L_back is not None and L_dark is not None and L_back > L_dark + 60,
      f"L_back={L_back:.1f}")

check("切换跟随系统", tap_tag("theme_system"))
time.sleep(1.2)
check("跟随系统被选中", any(n["rid"] == "theme_system" and n["checked"] == "true" for n in nodes(dump())))

# 版本号读取自实际包配置
check("滚动到关于分组", scroll_to_tag("settings_back") or True)
for _ in range(4):
    adb("shell input swipe 600 1900 600 800 260"); time.sleep(0.8)
about = texts(dump())
check("关于页显示真实版本号 0.2.0-g1", "0.2.0-g1" in about, str(about[-8:]))
check("关于页显示应用名", "萌芽人生" in about and "Mengya Life" in about)
check("关于页显示版本标签", "当前版本" in about)
shot("12-settings-about")

# ---------- 返回一级页面：主题作用于全 App ----------
adb("shell input keyevent KEYCODE_BACK"); time.sleep(1.6)
main_shot = shot("13-main-after-theme")
L_main = png_luminance(main_shot)
check("一级页面同样跟随主题（浅色化）", L_main is not None and L_main > 150, f"main_L={L_main:.1f}")

# ---------- 日记 ----------
tap_tag("tab_diary")
tap_tag("diary_new")
tap_tag("diary_input")
adb("shell input text 'Gate1%stest%sentry'")
time.sleep(1.0)
close_keyboard()
tap_tag("diary_save")
time.sleep(1.2)
dt = texts(dump())
check("日记保存后出现在列表", any("Gate1 test entry" in t for t in dt), str(dt[:5]))
check("新条目带「本次新建」标记", any("本次新建" in t for t in dt))
shot("14-diary-new-entry")

tap_tag("btn_settings")
adb("shell input keyevent KEYCODE_BACK"); time.sleep(1.5)
check("进设置再返回后日记内容仍在", any("Gate1 test entry" in t for t in texts(dump())))

# ---------- 顾问 ----------
tap_tag("tab_advisor")
tap_tag("advisor_input")
adb("shell input text 'How%sdo%sI%sstart'")
time.sleep(1.0)
close_keyboard()
tap_tag("advisor_send")
time.sleep(1.6)
at = texts(dump())
check("顾问发送后出现用户消息", any("How do I start" in t for t in at), str(at[:4]))
check("顾问发送后有明确演示提示", any("（演示）" in t for t in at))
shot("15-advisor-sent")

# ---------- 滚动 ----------
close_keyboard()
tap_tag("tab_trends")
before = texts(dump())
adb("shell input swipe 600 1900 600 700 300")
time.sleep(1.6)
after = texts(dump())
check("趋势页可滚动", before != after, f"滑动后新可见: {[t for t in after if t not in before][:3]}")
shot("16-trends-scrolled")

# ---------- 稳定性 ----------
check("无崩溃日志", "com.mengyalife.app" not in adb("shell logcat -b crash -d"))
check("应用进程存活", "com.mengyalife.app" in adb("shell ps -A"))

sys.exit(0 if summary() else 1)
