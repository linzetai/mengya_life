import sys, time
sys.path.insert(0, "/tmp")
from g2lib import *

EXPECT_TITLE = "汕头"
EXPECT_BODY_PART = "今天从汕头"

tap_tag("tab_diary")
time.sleep(1.2)
ts = texts(dump())
check("中文日记标题在列表中", any(EXPECT_TITLE == t for t in ts), str(ts[-6:]))
check("中文正文摘要可见", any(EXPECT_BODY_PART in t for t in ts))
shot("09-chinese-entry")

print(">>> 冷启动后中文记录仍在")
restart_app()
tap_tag("tab_diary")
time.sleep(1.5)
check("重启后中文标题仍在", wait_text(EXPECT_TITLE, 8))
check("重启后中文正文仍在", any(EXPECT_BODY_PART in t for t in texts(dump())))
shot("10-chinese-after-restart")

print(">>> 打开详情确认中文完整")
tap_text(EXPECT_TITLE)
time.sleep(1.5)
dts = texts(dump())
check("详情页正文完整", any("明天要上班了" in t for t in dts), str(dts[:8]))
shot("11-chinese-detail")
sys.exit(0 if summary() else 1)
