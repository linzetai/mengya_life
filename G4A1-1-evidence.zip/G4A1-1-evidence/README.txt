G4A-1.1 完整备份验证收口证据包
HEAD: 691abc15a982381d110f9f70cb802e285b5f4d83
Base: fb46f29
生成时间: 2026-11-05 Asia/Shanghai

目录:
- source/ : 备份实现、QA夹具、故障注入、UI/依赖/Manifest/规则
- tests/  : JVM测试源码、tests/test-map.json、verify CLI/选择规则
- verify/ : scripts/verify.sh、QA脚本、独立Node探针
- evidence/: JVM 274/274、L1/L2真机报告、10表120列、失败路径、样本/探针
- docs/   : REPORT-G4A1-1 / G4A1-1-ACCEPTANCE 及本批更新文档
- git/    : HEAD、提交清单、变更文件、status

关键结果:
- 10/10 表非空（23行）；120/120 列；field-diff 0 errors
- payloadSha256 独立匹配；perTableSha256 10/10 匹配
- 真实文件 15,373 B；端到端 18.07s
- 失败路径 6场景/45断言 PASS
- L1 PASS 647.5s；L2 PASS 1248.4s；JVM 274/274 PASS

不含真实个人数据/真实API Key；样本为QA假数据加密文件。
